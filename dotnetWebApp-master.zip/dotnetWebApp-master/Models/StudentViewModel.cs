namespace dotnetWebApp.Models;

public class StudentViewModel
{
    public string Name { get; set; }

    public string Surname  { get; set; }

    public string Course  { get; set; }

    public StudentViewModel(){}

    public StudentViewModel(string name,  string surname, string course){
         Name =name;
         Surname = surname;
         Course = course;
    }
}
