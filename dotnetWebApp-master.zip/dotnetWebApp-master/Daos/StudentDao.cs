using System;
using MySql.Data;
using MySql.Data.MySqlClient;
using  dotnetWebApp.Models;
using  dotnetWebApp.Services;

namespace dotnetWebApp.Daos
{
    public class StudentDao: StudentService
    {

        private readonly ILogger<StudentDao> _logger;
        private static string connStr = "server=localhost;user=ambeswa;password=Masakabavuma_23;database=STUDENTS_DB";

        public StudentDao(){
        }
        public StudentDao(ILogger<StudentDao> logger) =>
                _logger = logger;

        public List<StudentViewModel> getStudents() {
            MySqlConnection conn = new MySqlConnection(connStr);
            List<StudentViewModel> students = new List<StudentViewModel>();
            try
            {
                conn.Open();

                string sql = "SELECT Name, Surname, Center From student_details";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                    students.Add(new StudentViewModel((string) rdr[0], (string) rdr[1], (string) rdr[2]));
                }
                rdr.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            return students;
        }

        public StudentViewModel getStudentById( string Center) {
             MySqlConnection conn = new MySqlConnection(connStr);
            var student = new StudentViewModel();
            try
            {
                conn.Open();
                string sql = $"SELECT Name, Surname, Course From student_details where Center = {Center}";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                MySqlDataReader rdr = cmd.ExecuteReader();
                while (rdr.Read())
                {
                   student.Name = (string) rdr[0];
                   student.Surname = (string) rdr[1];
                   student.Course = (string) rdr[2];
                }
                rdr.Close();
                conn.Close();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.ToString());
            }
            conn.Close();
            return student;
        }

        public string addStudent( StudentViewModel student) {
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                conn.Open();
                string sql = $"INSERT INTO student_details (Name, Surname, Course) VALUES ({student.Name}, '{student.Surname}', {student.Course})";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                return $"Student with id {student.Name} added";
            }
            catch (MySqlException ex)
            {
                string msg = $"Student, with Name {student.Name} already exists.";
                Console.WriteLine($"Post action failed, student with Name {student.Name}  already exists.");
                conn.Close();
                return msg;
            }

        }

        public string updateStudent( StudentViewModel student) {
            MySqlConnection conn = new MySqlConnection(connStr);
            try
            {
                conn.Open();
                string sql = $"UPDATE student_details  set Name = '{student.Name}', Surname = {student.Surname} where Name = {student.Name}";
                MySqlCommand cmd = new MySqlCommand(sql, conn);
                cmd.ExecuteNonQuery();
                conn.Close();
                return $"Student with Name {student.Name} updated";
            }
            catch (MySqlException ex)
            {
                Console.WriteLine("Student not found.");
                conn.Close();
                 return $"Student with Name {student.Name}, not found.";
            }
        }

         public string removeStudent(string name) {
            MySqlConnection conn = new MySqlConnection(connStr);
             try
             {
                 conn.Open();
                 string sql = $"DELETE FROM student_details WHERE Name = {name}";
                 MySqlCommand cmd = new MySqlCommand(sql, conn);
                 cmd.ExecuteNonQuery();
                 conn.Close();
                 return $"Student with Name {name} deleted";
             }
             catch (MySqlException ex)
             {
                 Console.WriteLine("Student with Name {Name}, not found.");
                 conn.Close();
                 return $"Student with Name {name}, not found.";
             }

         }
    }
}
