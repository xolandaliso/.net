using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using dotnetWebApp.Models;
using dotnetWebApp.Services;
using dotnetWebApp.Daos;

namespace dotnetWebApp.Controllers;

public class StudentsController : Controller
{
    private readonly ILogger<StudentsController> _logger;

    public StudentsController(ILogger<StudentsController> logger)
    {
        _logger = logger;
    }

   public IActionResult Index()
    {
        StudentService _studanetDao = new StudentDao();
        return View( _studanetDao.getStudents());
    }

    public IActionResult GetAll()
    {
        StudentService _studanetDao = new StudentDao();
        return View( _studanetDao.getStudents());
    }

    public IActionResult Details(string name)
    {
        StudentService _studanetDao = new StudentDao();
        return View(_studanetDao.getStudentById(name));
    }

    public IActionResult Create(string name, string surname, string course)
    {

        StudentService _studanetDao = new StudentDao();
        ViewBag.results = null;
        if(name!=null && surname!=null && course!=null){
           ViewBag.results = _studanetDao.addStudent(new StudentViewModel(name, surname, course));
          }
        return View();
    }

    public IActionResult Update(string name, string surname, string course)
    {
        StudentService _studanetDao = new StudentDao();
        ViewBag.results = null;
        if(name!=null && surname!=null & course!=null){
           ViewBag.results = _studanetDao.updateStudent(new StudentViewModel(name, surname, course));
          }
        return View();
    }

    public RedirectToActionResult Delete(string name)
    {

        StudentService _studanetDao = new StudentDao();
        ViewBag.results = _studanetDao.removeStudent(name);
        return RedirectToAction(actionName: "Index", controllerName: "Students");
    }

   public IActionResult Search(string keyword)
    {
        StudentService _studanetDao = new StudentDao();
        if(keyword==null){
            return RedirectToAction(actionName: "GetAll", controllerName: "Students");
        }
        return View( "GetAll", _studanetDao.getStudents().Where(st => st.Name.Contains(keyword)).ToList() );
    }

    public IActionResult Privacy()
    {
        return View();
    }
}   
